package com.praktikum.data;

import com.praktikum.users.User;
import com.praktikum.data.Item;
import java.util.ArrayList;

public class DataStore {
    public static ArrayList<User> userList = new ArrayList<>();
    public static ArrayList<Item> reportedItems = new ArrayList<>();
} 