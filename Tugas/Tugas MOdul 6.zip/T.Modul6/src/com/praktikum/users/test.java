package com.praktikum.users;

public class test {
    // Dummy class for structure only
} 