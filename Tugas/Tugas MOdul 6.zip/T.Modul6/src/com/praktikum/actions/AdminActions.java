package com.praktikum.actions;

public interface AdminActions {
    public void manageItems();

    public void manageUsers();
}
