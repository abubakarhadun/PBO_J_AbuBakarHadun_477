package com.praktikum.actions;

public interface MahasiswaAction {
    public void reportItem();

    public void viewReportedItems();
}
